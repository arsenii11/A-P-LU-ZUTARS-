/******************************
 * Matvei Barbashov, mb21162
 * D15. The program file for Tetragon class.
 * Date: 20.09.2021
 * ****************************/

#include <iostream>
#include "program.h"

using namespace std;

//Implemented function of the tetragon constructor
Tetragon::Tetragon(float a, float b, float c, float d, float angle) {
    m_a = a;
    m_b = b;
    m_c = c;
    m_d = d;
    m_angle = angle;
}

//Implemented function of the tetragon destructor
Tetragon::~Tetragon() {
    cout << "The tetragon has been destroyed" << endl;
}

//Implemented change function
void Tetragon::Change(float a, float b, float c, float d, float angle) {
    //Add values to the parameters
    m_a += a;
    m_b += b;
    m_c += c;
    m_d += d;
    m_angle += angle;
}

//Implemented print function
void Tetragon::Print() {
    //Printing parameters of the tetragon
    cout << "Side a: " << m_a << "\nSide b: " << m_b << "\nSide c: " << m_c << "\nSide d: " << m_d << "\nAngle: "
         << m_angle << endl;
}

//Implemented calculate function
void Tetragon::Calculate() {
    string type = "other";

    //The case of equality pairwise sides
    if (m_a == m_c && m_b == m_d) {
        type = "parallelogram";

        //The case of the right angle
        if (m_angle == 90) {
            type = "rectangle";
            if (m_a == m_b) type = "square";
        } else if (m_a == m_b) type = "rhombus";
    }

    cout << "Type of the tetragon is " << type << endl;
}
