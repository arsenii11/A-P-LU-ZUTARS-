/******************************
 * Matvei Barbashov, mb21162
 * D15. The header file for Tetragon class.
 * Date: 20.09.2021
 * ****************************/

#ifndef D15_PROGRAM_H
#define D15_PROGRAM_H

class Tetragon {
private:
    float m_a; //The value for 1st. side of the tetragon
    float m_b; //The value for 2nd. side of the tetragon
    float m_c; //The value for 3d. side of the tetragon
    float m_d; //The value for 4th. side of the tetragon
    float m_angle; //The value for the angle of the tetragon

public:
    Tetragon(float a, float b, float c, float d, float angle); //The constructor for the tetragon

    ~Tetragon(); //The destructor for the tetragon

    void Change(float a, float b, float c, float d, float angle); //The function to add values to the parameters of the tetragon

    void Print(); //The function to print the parameters of the tetragon

    void Calculate(); //The function to calculate type of the tetragon
};

#endif //D15_PROGRAM_H
