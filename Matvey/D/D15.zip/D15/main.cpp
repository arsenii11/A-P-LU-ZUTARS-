/******************************
 * Matvei Barbashov, mb21162
 * D15. Create class "tetragon" containing 5 digits -
 * 4 lengths of sides and 1 angle (value 1..179 degrees).
 * The following class methods should be created:
 * (1) a constructor to initialize an object with given initial values,
 * (2) destructor which should notify about deleting the object,
 * (3) method "change" with 5 given parameters to add given parameter values to lengths of sides and angle,
 * (4) method "print" to print all length of sides and angle,
 * (5) method "calculate" to calculate type of tetragon: square, rectangle, rhombus, parallelogram or other
 * Program created: 20.09.2021
 * ****************************/

#include <iostream>
#include "program.h"

using namespace std;

int main() {
    float a, b, c, d, angle; //Local values for sides and angle of tetragon

    //Data input
    cout << "Input side 'a' of the tetragon:" << endl;
    cin >> a;
    cout << "Input side 'b' of the tetragon:" << endl;
    cin >> b;
    cout << "Input side 'c' of the tetragon:" << endl;
    cin >> c;
    cout << "Input side 'd' of the tetragon:" << endl;
    cin >> d;
    cout << "Input angle of the tetragon:" << endl;
    cin >> angle;

    //Checking for the correctness of the data
    if (a > 0 && b > 0 && c > 0 && d > 0 && angle > 0 && angle < 180) {
        Tetragon tetragon(a, b, c, d, angle); //Creating an instance of the tetragon

        cout << "Properties of the tetragon:" << endl;
        tetragon.Print(); //Printing parameters of the tetragon
        tetragon.Calculate(); //Printing type of the tetragon

        cout << "Do you want to add values to the parameters of the tetragon? (1 or 0)" << endl;
        int key;
        cin >> key;
        do {
            //Data input
            cout << "Input value to the 'a' side:" << endl;
            cin >> a;
            cout << "Input value to the 'b' side:" << endl;
            cin >> b;
            cout << "Input value to the 'c' side:" << endl;
            cin >> c;
            cout << "Input value to the 'd' side:" << endl;
            cin >> d;
            cout << "Input value to the angle" << endl;
            cin >> angle;

            tetragon.Change(a, b, c, d, angle); //Modifying parameters of the tetragon
            cout << "Modified properties of the tetragon:" << endl;
            tetragon.Print(); //Printing parameters of the tetragon
            tetragon.Calculate(); //Printing type of the tetragon

            cout << "Do you want to add values to the parameters of the tetragon? (1 or 0)" << endl;
            cin >> key;
        } while (key == 1);
    } else cout << "Entered data is incorrect \n Please, input other values" << endl;
    return 0;
}
