// Yulpatova Sofya, sy21002
// B21. Given two natural numbers m and n. Print all prime numbers in interval [m,n].
// Create and use a function to check - is number prime number.
// The date of creation is 19.09.2021


#include <iostream>
#include <CMath>

using namespace std;

// function is number prime

bool is_prime(int n) {
    for (int i = 2; i <= sqrt(n); i++) { // loop until the sqrt *
        if (n % i == 0) { // if n divided by i entirely
            return false;
        }
    }
    return true;
}


// * we can loop until the sqrt(number) because after the sqrt divisors will repeat

// main program
int main() {
    int ok;
    do {
        int m, n; // variables m and n are integer, m contains start point, n - end point
        cout << "enter the start point" << endl;
        cin >> m; // entering the start point
        cout << "enter the end point" << endl;
        cin >> n; // entering the end point
        if (m <= 0 or n <= 0) { // checking that m and n are natural numbers
            cout << "Warning! m and n must be natural numbers" << endl; // Error
        } else if (m >
                   n) { // checking that m less or equal to n, because the start point can not be more than the end point
            cout << "Warning! m must be less then n" << endl; // Error
        } else { // if all are okay
            for (; m <= n; m++) { // looping starting with m and until the n
                if (is_prime(m)) { // checking function is_prime true or false
                    cout << m << " is a prime number" << endl;
                }
            }
        }


            cout << "Continue (1) or quit (0)?" << endl;
            cin >> ok;
        }
        while (ok == 1);
}

