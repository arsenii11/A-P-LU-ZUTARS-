'''
Yulpatova Sofya, sy21002
B21. Given two natural numbers m and n. Print all prime numbers in interval [m,n].
Create and use a function to check - is number prime number.
The date of creation is 19.09.2021
'''


def prime(n):  # is prime function
    ''' The loop until the sqrt to find the divider and said that it is not the prime number, because after sqrt will be the equal divisors '''
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:  # checking the divisibility
            return False  # returning the result
    return True


m = int(input("enter the start point: "))  # the value contains the start point
n = int(input("enter the end point: "))  # the value contains the end point

while (m <= 0 or n <= 0) or (m > n):
    if m <= 0 or n <= 0:  # checking that m and n are natural numbers
        print('Warning! m and n must be natural numbers')
    elif m > n:  # checking that m less or equal to n, because the start point can not be more than the end point
        print('Warning! m must be less then n')

    # another attempt to enter the right numbers

    m = int(input("enter the start point: "))  # the value contains the start point
    n = int(input("enter the end point: "))  # the value contains the end point

for i in range(m, n + 1):  # the loop starts with m and ends with n
    if prime(i):  # checking that number i is prime
        print(i, 'is a prime number')  # printing prime numbers

