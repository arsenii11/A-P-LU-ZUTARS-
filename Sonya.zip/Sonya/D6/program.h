// Sofya Yulpatova 01.10.2021
// D6. Create class "Queue" (queue is a collection of data, where elements are added to the rear position,
// but removed from the front position), with array of integers of size 5 (for the queue up to 5 elements),
// and additional information about actual size of the queue. The following class methods should be created:
// (1) a constructor to initialize an object with an empty queue,
// (2) destructor which should notify about deleting the object,
// (3) method "enqueue" adds element, if the queue is not full,
// (4) method "dequeue", which removes element (from the opposite side) and returns its value,
// (5) method "count" to return the size of the queue,
// (6) method "IsEmpty" to return whether the queue is empty.
// N.B. Before solving the task, study the meaning of 'queue' in computer science - this will help.
//

#ifndef D6_PROGRAM_H
#define D6_PROGRAM_H

class Queue {
private:
    int m_size; // size of queue
    int m_queue[5]; // current queue


public:
    Queue(); // constructor

    ~Queue(); // destructor

    void Enqueue(int number); // add one element in queue

    int Dequeue(); // delete first element in queue

    int Count(); // the length of current queue

    bool IsEmpty(); // checking is the queue empty or not

};


#endif //D6_PROGRAM_H
