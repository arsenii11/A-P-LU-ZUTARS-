//
// Sofya Yulpatova 01.10.2021
// D6. Create class "Queue" (queue is a collection of data, where elements are added to the rear position,
// but removed from the front position), with array of integers of size 5 (for the queue up to 5 elements),
// and additional information about actual size of the queue. The following class methods should be created:
// (1) a constructor to initialize an object with an empty queue,
// (2) destructor which should notify about deleting the object,
// (3) method "enqueue" adds element, if the queue is not full,
// (4) method "dequeue", which removes element (from the opposite side) and returns its value,
// (5) method "count" to return the size of the queue,
// (6) method "IsEmpty" to return whether the queue is empty.
// N.B. Before solving the task, study the meaning of 'queue' in computer science - this will help.
//

#include <iostream>
#include "program.h"

using namespace std;


Queue::Queue() {
    m_size = 0; // creating queue
    for (int i = 0; i < m_size; i++) {
        m_queue[i] = 0; // creating queue with 0
    }
}


Queue::~Queue() {
    cout << "Queue was deleted" << endl; // the message when deleting queue
}

int Queue::Count() {
    return m_size; // count is the size of queue
}


void Queue::Enqueue(int number) {
    if (Count() < 5) { // checking that len(queue) is less than 5
        m_size += 1;
        m_queue[m_size - 1] = number; // adding the number

    } else { // if len is 5 or more
        cout << "Error, the number of elements is more then 5" << endl; // error
    }
}

int Queue::Dequeue() {
    int elem = m_queue[0]; // the first element
    m_size--; // size -- because me will delete the number
    int fake_queue[5] = {0, 0, 0, 0, 0}; // fake queue for new queue
    for (int i = 1; i < m_size - 1; i++) { // creating fake queue
        fake_queue[i - 1] = m_queue[i];
    }
    for (int i = 0; i < m_size; i++) { // fake queue must be current queue
        m_queue[i] = fake_queue[i];
    }


    return elem; // the first (not current) element
}


bool Queue::IsEmpty() {
    return m_size == 0; // True or false (is the queue empty???)
}
