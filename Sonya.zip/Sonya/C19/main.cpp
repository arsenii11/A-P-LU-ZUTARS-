// Create program in C++ by making use of described or other functions. Requirements are the same as for the previous task, see published detailed requirements.
//
//C19. Given array with non-negative integers A(n).
// Find an index of the element for which the sum of elements before has the minimum difference form sum of elements after the element.
// If there are several elements with this characteristic, show all of them.


//

#include <iostream>
#include <CMath>

using namespace std;

// function to count amount before the current element
int sum_before(int *array, int n) {
    int sum_before = 0; // the value contains sum of all elements before the current element
    for (int i = 0; i < n; i++) { // the loop to count the sum
        sum_before += array[i];
    }
    return sum_before;
}
// function to count amount after the current element

int sum_after(int *array, int n, int counter) {
    int sum_after = 0; // the value contains sum of all elements after the current element
    for (int i = n + 1; i < counter; i++) { // the loop to count the sum
        sum_after += array[i];
    }
    return sum_after;
}


// main
int main() {
    int ok;
    do {
        int counter=0; // the value-counter for
        cout << "enter the count of numbers" << endl;
        cin >> counter;
        while (counter <= 0){
            cout << "counter is a NATURAL number" << endl;
            cout << "enter the count of numbers" << endl;
            cin >> counter;
        }
        int *array = new int[counter]; // array for the all elements
        int index = 0; // the index of an element in the array, for which the difference between sum of elements before and
        // sum of elements after the current is the minimum
        int min_differ = 400000000; // the value contains the minimal difference
        int *eq = new int[counter];// the array to save the equal indexes of elements
        int counter_eq = 0; // counter for equal elements
        int index_eq = 0; // the value to save current position when finding the indexes of the equal sums
        // loop to fill elements
        for (int i = 0; i < counter; i++) {
            cout << "enter a number into array " << endl;
            cin >> array[i];
            while (array[i] < 0) {
                cout << "number must be NON-NEGATIVE" << endl;
                cout << "try again" << endl;
                cout << "enter a number into array " << endl;
                cin >> array[i];
            }
        }
        // loop to count the difference and save it
        for (int i = 0; i < counter; i++) {
            int differ = abs(sum_before(array, i) -
                             sum_after(array, i, counter)); // counting the difference sum of elements before and
            // sum of elements after the current element
            if (differ < min_differ) { // if difference less than the min_difference
                min_differ = differ; // updating the min_differ
                index = i; // updating the index
            }
        }
        // find the equal summations
        for (int i = 0; i < counter; i++){
            int differ = abs(sum_before(array, i) -
                             sum_after(array, i, counter));
            if (differ == min_differ){

                eq[counter_eq] = i;
                counter_eq ++;
            }
        }
        // printing

        if (counter_eq > 0) {
            for (int i = 0; i < counter_eq; i ++)
                cout << eq[i] << endl;
        }
        else{
            cout << index << endl;
        }

        delete[] array;
        delete[] eq;

        cout << "Continue (1) or quit (0)?" << endl;
        cin >> ok;
    }
    while (ok == 1);
    return 0;
}
